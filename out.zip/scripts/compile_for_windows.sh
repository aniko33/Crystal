random_str=$(openssl rand -base64 125)

export RUSTFLAGS="--remap-path-prefix $HOME=~"
export LITCRYPT_ENCRYPT_KEY=$random_str

cargo build -r --target x86_64-pc-windows-gnu
mv target/x86_64-pc-windows-gnu/release/scr.exe .
